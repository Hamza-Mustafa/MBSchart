//
//  ViewController.swift
//  MBSchart
//
//  Created by Hamza Mustafa on 05/11/2020.
//

import UIKit
import MSBBarChart

class ViewController: UIViewController {

    @IBOutlet weak var barChart1: MSBBarChartView!
    @IBOutlet weak var barChart2: MSBBarChartView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.barChart1.setOptions([.yAxisTitle("Time"), .yAxisNumberOfInterval(10)])
        self.barChart1.assignmentOfColor = [1..<5:#colorLiteral(red: 0.05882352963, green: 0.180392161, blue: 0.2470588237, alpha: 1) ,5..<10:#colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1),10..<15:#colorLiteral(red: 0.1411764771, green: 0.3960784376, blue: 0.5647059083, alpha: 1),15..<20:#colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1),20..<25:#colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1),25..<35:#colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1),35..<50:#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1) ]
        self.barChart1.setDataEntries(values: [12,34,56,78,90,101,140])
        self.barChart1.setXAxisUnitTitles(["a","b","c","d","e","f","g"])
        self.barChart1.start()
        
        self.barChart2.setOptions([.yAxisTitle("Time"), .yAxisNumberOfInterval(10)])
        self.barChart2.assignmentOfColor = [1..<5:#colorLiteral(red: 0.1921568662, green: 0.007843137719, blue: 0.09019608051, alpha: 1) ,5..<10:#colorLiteral(red: 0.3098039329, green: 0.01568627544, blue: 0.1294117719, alpha: 1),10..<15:#colorLiteral(red: 0.4392156899, green: 0.01176470611, blue: 0.1921568662, alpha: 1),15..<20:#colorLiteral(red: 0.5725490451, green: 0, blue: 0.2313725501, alpha: 1),20..<25:#colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1),25..<35:#colorLiteral(red: 0.8549019694, green: 0.250980407, blue: 0.4784313738, alpha: 1),35..<50:#colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1) ]
        self.barChart2.setDataEntries(values: [12,34,56,78,90,101,140])
        self.barChart2.setXAxisUnitTitles(["a","b","c","d","e","f","g"])
        self.barChart2.start()
    }
}
